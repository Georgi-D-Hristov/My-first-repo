﻿using System;
using System.Collections.Generic;
using System.Text;


public class Car
{
    private const double maxFuel = 160;
    private double fuelAmount;

    public Car(int hp, double fuelAmount, Type tyre)
    {
        this.Hp = hp;
        this.FuelAmount = fuelAmount;
        this.Tyre= tyre;
    }
    public int Hp { get;  }

    

    public double FuelAmount
    {
        get { return fuelAmount; }
        set
        {
            if (value<0)
            {
                throw new ArgumentException(ErrorMeseges.OutOfFuel);
            }
            fuelAmount = Math.Min(value, maxFuel);
        }
    }

    public Type Tyre { get; private set; }
}

