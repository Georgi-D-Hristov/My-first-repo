﻿using System;
using System.Collections.Generic;
using System.Text;


public static class ErrorMeseges
{
    public static string BlownTyre => "Blown Tyre";

    public static string OutOfFuel => "Out of fuel";

    public static string Crashed => "Crashed";
}
