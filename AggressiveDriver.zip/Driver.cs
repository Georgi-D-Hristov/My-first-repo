﻿using System;
using System.Collections.Generic;
using System.Text;


public abstract class Driver
{
  
    public string Name { get; }

    public double TotalTime { get; private set; }

    public Car Car { get;  }

    public double FuelConsumationPerKm { get; }

    public double Speed => (Car.Hp + Car.Tyre.Degradation) / Car.FuelAmount;
}

